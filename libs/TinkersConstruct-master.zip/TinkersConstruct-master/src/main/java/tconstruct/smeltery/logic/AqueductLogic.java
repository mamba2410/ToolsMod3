package tconstruct.smeltery.logic;

import net.minecraft.tileentity.TileEntity;

public class AqueductLogic extends TileEntity // implements ITankContainer
{

    /*
     * @Override public int fill (ForgeDirection from, FluidStack resource,
     * boolean doFill) { return 0; }
     * 
     * @Override public int fill (int tankIndex, FluidStack resource, boolean
     * doFill) { return 0; }
     * 
     * @Override public FluidStack drain (ForgeDirection from, int maxDrain,
     * boolean doDrain) { return null; }
     * 
     * @Override public FluidStack drain (int tankIndex, int maxDrain, boolean
     * doDrain) { return null; }
     * 
     * @Override public ILiquidTank[] getTanks (ForgeDirection direction) {
     * return null; }
     * 
     * @Override public ILiquidTank getTank (ForgeDirection direction,
     * FluidStack type) { return null; }
     */

}
