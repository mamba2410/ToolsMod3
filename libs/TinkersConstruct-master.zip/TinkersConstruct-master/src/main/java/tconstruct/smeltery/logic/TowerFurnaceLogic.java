package tconstruct.smeltery.logic;

import mantle.blocks.abstracts.AdaptiveInventoryLogic;
import mantle.blocks.iface.*;

//Not actually abstract
public abstract class TowerFurnaceLogic extends AdaptiveInventoryLogic implements IActiveLogic, IFacingLogic, IMasterLogic
{

}
