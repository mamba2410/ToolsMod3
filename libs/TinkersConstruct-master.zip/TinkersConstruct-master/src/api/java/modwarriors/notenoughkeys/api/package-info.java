
@API(owner = "Not Enough Keys", provides = "API_NEK",
		apiVersion = "1.0.0") package modwarriors.notenoughkeys.api;

import cpw.mods.fml.common.API;
