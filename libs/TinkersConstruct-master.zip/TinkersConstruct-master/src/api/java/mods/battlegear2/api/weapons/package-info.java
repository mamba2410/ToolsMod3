@API(owner = "battlegear2", provides = "Weapons", apiVersion = "0.1")
package mods.battlegear2.api.weapons;

import cpw.mods.fml.common.API;