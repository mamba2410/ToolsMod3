@API(owner = "battlegear2", provides = "DualWield", apiVersion = "0.1")
package mods.battlegear2.api;

import cpw.mods.fml.common.API;