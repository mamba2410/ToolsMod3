@API(owner = "zeldaswordskills", provides = "ZeldaAPI", apiVersion = "0.3")
package zeldaswordskills.api;

import cpw.mods.fml.common.API;
