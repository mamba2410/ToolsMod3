@API(owner = "zeldaswordskills", provides = "ZeldaItemAPI", apiVersion = "0.3")
package zeldaswordskills.api.item;

import cpw.mods.fml.common.API;
